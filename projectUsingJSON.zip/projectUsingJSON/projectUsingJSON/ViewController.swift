//
//  ViewController.swift
//  projectUsingJSON
//
//  Created by jyothi on 12/18/18.
//  Copyright © 2018 jyothi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    var URLSessionObj :URLSessionTask!
    var URLRequestObj :URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loginBtn(_ sender: UIButton) {
        URLRequestObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php")!)
         URLRequestObj.httpMethod = "post"
        var dataToSend = "funcName=verifyLogin&registeredEmail=\(emailTF.text!)& registeredPassword=\(passwordTF.text!)"
        URLRequestObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        dataTaskObj = URLSession.shared.dataTask(with: URLRequestObj)
        { (data, res, err) in
            print(data!)
            print("got response from server")
            
            do{
                var serverresponse = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(serverresponse)
            } catch {
                print("data not print")
            }
            
            print("Login successFul")
        }
        
        self.dataTaskObj.resume()
        
    }
    
    
    @IBAction func attendanceDetails(_ sender: UIButton) {
        
    URLRequestObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php")!)
       URLRequestObj.httpMethod = "post"
        var datatosend = "funcName=getUserAttendance&studentIDByAdmin=NoValue"
        URLRequestObj.httpBody = datatosend.data(using: String.Encoding.utf8)
        let attendanceDataTask = URLSession.shared.dataTask(with: URLRequestObj)
        { (data, res, err) in
            print(data!)
            do{
                let attendanceDetails = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                print(attendanceDetails)
                print("got response from server")
                
            }catch{
                print(error)
            }
            
        }
        attendanceDataTask.resume()
    }
}

